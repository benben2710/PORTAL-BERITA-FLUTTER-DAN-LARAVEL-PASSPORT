package com.example.portal_berita_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
